# FlexiFlow

FlexiFlow is a small, library-first async engine that wires:

- Components (rules + state machine)
- An async event bus (pub/sub with priority, filters, and sequential/concurrent delivery)
- Structured logging with correlation IDs
- A minimal CLI for demos

## Install

Editable install:

```bash
pip install -e .
```

Dev dependencies (tests):

```bash
pip install -e ".[dev]"
```

Optional hot reload:

```bash
pip install -e ".[reload]"
```

Optional API:

```bash
pip install -e ".[api]"
```

## Quickstart

```bash
flexiflow register --config examples/config.yaml --start
flexiflow handle --config examples/config.yaml confirm --content confirmed
flexiflow handle --config examples/config.yaml complete
flexiflow update_rules --config examples/config.yaml examples/new_rules.yaml
```

## Environment variable config

If you omit `--config`, FlexiFlow will use:

- `FLEXIFLOW_CONFIG=/path/to/config.yaml`

Example:

```bash
set FLEXIFLOW_CONFIG=examples/config.yaml
flexiflow register --start
```

## Message types in the default state machine

- start
- confirm (requires content == "confirmed")
- cancel
- complete
- error
- acknowledge
