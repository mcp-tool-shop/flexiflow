from __future__ import annotations

import asyncio
from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, DefaultDict, List, Optional

Handler = Callable[[Any], Awaitable[None]]
FilterFn = Callable[[str, Any], bool]


@dataclass(frozen=True)
class Subscription:
    priority: int
    component_name: str
    handler: Handler
    filter_fn: Optional[FilterFn] = None


class AsyncEventManager:
    """Async pub/sub bus with priorities, optional filters, and sequential/concurrent delivery."""

    def __init__(self, logger: Any = None) -> None:
        self._events: DefaultDict[str, List[Subscription]] = defaultdict(list)
        self._logger = logger

    async def subscribe(
        self,
        event_name: str,
        component_name: str,
        handler: Handler,
        priority: int = 3,
        filter_fn: Optional[FilterFn] = None,
    ) -> None:
        if not (1 <= priority <= 5):
            raise ValueError("priority must be an integer between 1 and 5")

        self._events[event_name].append(
            Subscription(priority=priority, component_name=component_name, handler=handler, filter_fn=filter_fn)
        )

    async def publish(
        self,
        event_name: str,
        data: Any = None,
        *,
        delivery: str = "sequential",   # "sequential" | "concurrent"
        on_error: str = "continue",     # "continue" | "raise"
    ) -> None:
        if delivery not in ("sequential", "concurrent"):
            raise ValueError("delivery must be 'sequential' or 'concurrent'")
        if on_error not in ("continue", "raise"):
            raise ValueError("on_error must be 'continue' or 'raise'")

        subs = self._events.get(event_name, [])
        if not subs:
            return

        eligible = [s for s in subs if s.filter_fn is None or s.filter_fn(event_name, data)]
        ordered = sorted(eligible, key=lambda s: s.priority)

        if delivery == "concurrent":
            tasks = [asyncio.create_task(s.handler(data)) for s in ordered]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            if on_error == "raise":
                for r in results:
                    if isinstance(r, Exception):
                        raise r

            if self._logger:
                for r in results:
                    if isinstance(r, Exception):
                        self._logger.error("Error handling event %s: %s", event_name, r)
            return

        # sequential
        for s in ordered:
            try:
                await s.handler(data)
            except Exception as e:
                if self._logger:
                    self._logger.error("Error handling event %s: %s", event_name, e)
                if on_error == "raise":
                    raise
