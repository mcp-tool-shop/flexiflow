import pytest

from flexiflow.event_manager import AsyncEventManager


@pytest.mark.asyncio
async def test_priority_order():
    bus = AsyncEventManager()
    seen = []

    async def h1(_):
        seen.append("p1")

    async def h3(_):
        seen.append("p3")

    await bus.subscribe("x", "c1", h3, priority=3)
    await bus.subscribe("x", "c2", h1, priority=1)

    await bus.publish("x")
    assert seen == ["p1", "p3"]


@pytest.mark.asyncio
async def test_filter():
    bus = AsyncEventManager()
    seen = []

    async def h(_):
        seen.append("hit")

    await bus.subscribe("x", "c", h, priority=3, filter_fn=lambda name, data: data == 42)
    await bus.publish("x", 0)
    await bus.publish("x", 42)
    assert seen == ["hit"]


@pytest.mark.asyncio
async def test_on_error_continue():
    bus = AsyncEventManager()
    seen = []

    async def bad(_):
        raise RuntimeError("boom")

    async def good(_):
        seen.append("ok")

    await bus.subscribe("x", "c1", bad, priority=1)
    await bus.subscribe("x", "c2", good, priority=2)

    await bus.publish("x", on_error="continue")
    assert seen == ["ok"]


@pytest.mark.asyncio
async def test_on_error_raise():
    bus = AsyncEventManager()

    async def bad(_):
        raise RuntimeError("boom")

    await bus.subscribe("x", "c1", bad, priority=1)

    with pytest.raises(RuntimeError):
        await bus.publish("x", on_error="raise")
