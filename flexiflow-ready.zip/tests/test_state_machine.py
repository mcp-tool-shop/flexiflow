import pytest

from flexiflow.component import AsyncComponent
from flexiflow.state_machine import StateMachine


@pytest.mark.asyncio
async def test_state_transitions_happy_path():
    c = AsyncComponent(name="c", state_machine=StateMachine.from_name("InitialState"))
    await c.handle_message({"type": "start"})
    assert c.state_machine.current_state.__class__.__name__ == "AwaitingConfirmation"

    await c.handle_message({"type": "confirm", "content": "confirmed"})
    assert c.state_machine.current_state.__class__.__name__ == "ProcessingRequest"

    await c.handle_message({"type": "complete"})
    assert c.state_machine.current_state.__class__.__name__ == "InitialState"
